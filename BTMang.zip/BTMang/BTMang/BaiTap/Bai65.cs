﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTMang.BaiTap
{
    internal class Bai65
    {
        static void Main(string[] agrs)
        {
            int n_162;
            Console.Write("Moi ban nhap so luong phan tu cua mang: ");
            n_162 = int.Parse(Console.ReadLine());
            int[] a_162 = new int[n_162 + 1];
            Nhap(a_162, n_162);
            Console.Write("Mang cua ban la a_162[]: ");
            Xuat(a_162, n_162);
            Console.WriteLine("\nTrung binh cac so nguyen am le S = {0}", TBLe(a_162, n_162));
            XoaTrung(ref a_162, ref n_162);
            Console.Write("Mang cua ban sau khi xoa trung la a_162[]: ");
            Xuat(a_162, n_162);
            Console.ReadKey();
        }
        static void Nhap(int[] a_162, int n_162)
        {
            for (int i = 1; i <= n_162; i++)
            {
                Console.Write("a_162[{0}]: ", i);
                a_162[i] = int.Parse(Console.ReadLine());
            }
        }
        static void Xuat(int[] a_162, int n_162)
        {
            for (int i = 1; i <= n_162; i++)
            {
                Console.Write(" {0} ", a_162[i]);
            }
        }
        static float TBLe(int[] a_162, int n_162)
        {
            int tong = 0, dem = 0;
            for (int i = 1; i <= n_162; i++)
            {
                if (a_162[i] < 0 && a_162[i] % 2 != 0)
                {
                    tong = tong + a_162[i];
                    dem = dem + 1;
                }
            }
            return (float)tong / dem;
        }
        static void XoaTrung(ref int[] a_162, ref int n_162)
        {
            for (int i = 1; i < n_162; i++)
            {
                for (int j = i + 1; j <= n_162; j++)
                {
                    if (Math.Abs(a_162[i]) == Math.Abs(a_162[j]))
                    {
                        for (int k = j; k < n_162; k++)
                        {
                            a_162[k] = a_162[k + 1];
                        }
                        n_162 = n_162 - 1;
                    }
                }
            }
        }
    }
}
