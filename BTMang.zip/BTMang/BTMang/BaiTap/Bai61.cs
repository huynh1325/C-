﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTMang.BaiTap
{
    internal class Bai61
    {
        static void nhap(int[] a_162, int n_162)
        {
            Random rd_162 = new Random();
            for (int i_162 = 0; i_162 < n_162; i_162++)
            {
                a_162[i_162] = rd_162.Next(-100, 100);
            }
        }
        static void xuat(int[] a_162, int n_162)
        {
            for (int i_162 = 0; i_162 < n_162; i_162++)
            {
                Console.WriteLine(a_162[i_162] + " ");
            }
        }
        static int tinh(int[] a_162, int n_162)
        {
            int s_162 = 0;
            for (int i_162 = 0; i_162 < n_162; i_162++)
            {
                if (a_162[i_162] > 0)
                {
                    s_162 = s_162 + a_162[i_162];
                }
            }
            return s_162;
        }
        static void xoa(int[] a_162, int n_162)
        {
            int p_162 = int.Parse(Console.ReadLine());
            while (p_162 < 0 || p_162 > n_162 - 1) ;
            {
                for (int i_162 = p_162 + 1; i_162 < n_162; ++i_162)
                {
                    a_162[i_162 - 1] = a_162[i_162];
                }
            }
            n_162--;
            for (int i_162 = 0; i_162 < n_162; i_162++)
            {
                Console.WriteLine(a_162[i_162] + " ");
            }
        }
        static void Main(String[] args)
        {
            int[] a_162 = new int[100];
            Console.Write("Nhap n [1, 99]: ");
            int n_162 = int.Parse(Console.ReadLine());
            nhap(a_162, n_162);
            xuat(a_162, n_162);
            Console.WriteLine("Tong cac so nguyen duong = " + tinh(a_162, n_162));
            Console.Write("Nhap p [0, " + (n_162 - 1) + "]: ");
            xoa(a_162, n_162);
        }
    }
}
