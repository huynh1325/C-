﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTMang.BaiTap
{
    internal class Bai59
    {
        static void Main(string[] agrs)
        {
            string[] Can_162 = { "Canh", "Tan", "Nham", "Quy", "Giap", "At", "Binh", "Dinh", "Mau", "Ky" };
            string[] Chi_162 = { "Than", "Dau", "Tuat", "Hoi", "Ty", "Suu", "Dan", "Mao", "Thin", "Ty", "Ngo", "Mui" };
            int nam_162;
            Console.Write("Moi ban nhap nam duong: ");
            nam_162 = int.Parse(Console.ReadLine());
            Console.WriteLine("{0} - {1} {2}", nam_162, Can_162[nam_162 % 10], Chi_162[nam_162 % 12]);
            Console.WriteLine("{0} - {1} {2}", nam_162 + 60, Can_162[nam_162 % 10], Chi_162[nam_162 % 12]);
        }
    }
}
