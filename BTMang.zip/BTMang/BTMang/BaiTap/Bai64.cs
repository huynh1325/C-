﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTMang.BaiTap
{
    internal class Bai64
    {
        static void Main(string[] agrs)
        {
            int n_162, X_162;
            Console.Write("Nhap so luong phan tu cua mang: ");
            n_162 = int.Parse(Console.ReadLine());
            int[] a_162 = new int[n_162 + 1];
            Nhap(a_162, n_162);
            Xuat(a_162, n_162);
            Console.WriteLine("\nSo luy thuy cua 2 co trong mang: {0}", DemLuyThua(a_162, n_162));
            Console.Write("Nhap so X can xoa: ");
            X_162 = int.Parse(Console.ReadLine());
            XoaX(ref a_162, ref n_162, X_162);
            Xuat(a_162, n_162);
            Console.ReadKey();
        }
        static void Nhap(int[] a_162, int n_162)
        {
            for (int i = 1; i <= n_162; i++)
            {
                Console.Write("a_162[{0}]: ", i);
                a_162[i] = int.Parse(Console.ReadLine());
            }
        }
        static void Xuat(int[] a_162, int n_162)
        {
            Console.Write("Mang a_162[]: ");
            for (int i = 1; i <= n_162; i++)
            {
                Console.Write(" {0} ", a_162[i]);
            }
        }
        static int DemLuyThua(int[] a_162, int n_162)
        {
            int dem = 0;
            for (int i = 1; i <= n_162; i++)
            {
                int j = 2;
                while (Math.Pow(2, j) <= a_162[i])
                {
                    if (a_162[i] == Math.Pow(2, j))
                    {
                        dem++;
                    }
                    j++;
                }
            }
            return dem;
        }
        static void XoaX(ref int[] a_162, ref int n_162, int X_162)
        {
            for (int i = 1; i <= n_162; i++)
            {
                if (a_162[i] == X_162)
                {
                    for (int j = i; j < n_162; j++)
                    {
                        a_162[j] = a_162[j + 1];
                    }
                    n_162 = n_162 - 1;
                }
            }
        }
    }
}
