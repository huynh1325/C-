﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTMang.BaiTap
{
    internal class Bai63
    {
        static void Main(string[] agrs)
        {
            Random rd_162 = new Random();
            int n_162;
            Console.Write("Moi ban nhap so luong phan tu cua mang: ");
            n_162 = int.Parse(Console.ReadLine());
            int[] a_162 = new int[n_162 + 1];
            for (int i = 1; i <= n_162; i++)
            {
                a_162[i] = rd_162.Next(-100, 100);
            }
            Xuat(a_162, n_162);
            Console.WriteLine("\nSo phan tu chia het cho 4 va tan cung la 6: {0}", Dem(a_162, n_162));
            ThayDoiGT(ref a_162, n_162);
            Console.WriteLine("Thay phan tu le bang 2 lan gia tri cua no: ");
            Xuat(a_162, n_162);
        }

        static void Xuat(int[] a_162, int n_162)
        {

            for (int i = 1; i <= n_162; i++)
            {
                Console.Write(" {0} ", a_162[i]);
            }
        }
        static int Dem(int[] a_162, int n_162)
        {
            int dem_162 = 0;
            for (int i = 1; i <= n_162; i++)
            {
                if (a_162[i] % 4 == 0 && a_162[i] % 10 == 6)
                {
                    dem_162++;
                }
            }
            return dem_162;
        }
        static void ThayDoiGT(ref int[] a_162, int n_162)
        {
            for (int i = 1; i <= n_162; i++)
            {
                if (a_162[i] % 2 != 0)
                {
                    a_162[i] = 2 * a_162[i];
                }
            }
        }
    }
}
