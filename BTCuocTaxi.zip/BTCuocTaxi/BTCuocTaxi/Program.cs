﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTCuocTaxi
{
    internal class Program
    {
        int TongCuoc(int km)
        {
            int Cuoc = 0;
            if (km == 1)
            {
                Cuoc = 13000;
            }
            else if (km <= 30)
            {
                Cuoc = 13000 + ((km - 1) * 12000);
            }
            else
            {
                Cuoc = 361000 + ((km - 30) * 11000);
            }    
            return Cuoc;

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap so km: ");
            int km = Convert.ToInt32(Console.ReadLine());
            Program bt = new Program();
            Console.WriteLine("Tong so tien phai tra la: " + bt.TongCuoc(km));
        }
    }
}