﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap 3 canh cua tam giac: ");
            float a162 = float.Parse(Console.ReadLine());
            float b162 = float.Parse(Console.ReadLine());
            float c162 = float.Parse(Console.ReadLine());
            if (a162 > 0 && b162 > 0 && c162 > 0)
            {
                if (a162 + b162 > c162 && a162 + c162 > b162 && b162 + c162 > a162)
                    
                    Console.WriteLine("3 canh tren la 3 canh cua tam giac");
                else
                    Console.WriteLine("3 canh tren khong phai la 3 canh cua tam giac");
            }
            else
                Console.WriteLine("3 canh tren khong phai la 3 canh cua tam giac");
            Console.ReadLine();
        }
    }
}
