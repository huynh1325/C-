﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap so: ");
            int h162 = Convert.ToInt32(Console.ReadLine());
            if (h162 >= 0)
                Console.WriteLine("Day la so nguyen duong");
            else
                Console.WriteLine("Day la so nguyen am");
            Console.ReadLine();
        }
    }
}
