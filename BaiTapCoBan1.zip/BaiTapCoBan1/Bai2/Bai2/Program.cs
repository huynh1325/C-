﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiTapCSharp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap so: ");
            int h162 = Convert.ToInt32(Console.ReadLine());
            switch (h162)
            {
                case 0:
                    Console.WriteLine("Không");
                    break;
                case 1:
                    Console.WriteLine("Một");
                    break;
                case 2:
                    Console.WriteLine("Hai");
                    break;
                case 3:
                    Console.WriteLine("Ba");
                    break;
                case 4:
                    Console.WriteLine("Bốn");
                    break;
                case 5:
                    Console.WriteLine("Năm");
                    break;
                case 6:
                    Console.WriteLine("Sáu");
                    break;
                case 7:
                    Console.WriteLine("Bảy");
                    break;
                case 8:
                    Console.WriteLine("Tám");
                    break;
                case 9:
                    Console.WriteLine("Mười");
                    break;
                default:
                    Console.WriteLine("Chi nhap so nguyen duong mot chu so");
                    break;
            }
            Console.ReadLine();
        }
    }
}
