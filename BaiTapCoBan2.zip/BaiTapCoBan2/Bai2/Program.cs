﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap toa do xA: ");
            float xA = float.Parse(Console.ReadLine());
            Console.Write("Nhap toa do yA: ");
            float yA = float.Parse(Console.ReadLine());
            Console.Write("Nhap toa do xB: ");
            float xB = float.Parse(Console.ReadLine());
            Console.Write("Nhap toa do yB: ");
            float yB = float.Parse(Console.ReadLine());
            float AB = (float)Math.Sqrt(Math.Pow((xB - xA), 2) + Math.Pow((yB - yA), 2));
            Console.Write("Khoang cach AB la: " + Math.Abs(AB));
            Console.ReadLine();
        }
    }
}
