﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap phuong trinh: ");
            Console.Write("Nhap a: ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Nhap b: ");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.Write("Nhap c: ");
            int c = Convert.ToInt32(Console.ReadLine());
            if (a==0)
            {
                if (b == 0)
                {
                    if (c == 0)
                        Console.WriteLine("Phuong trinh co vo so nghiem!");
                    else
                        Console.WriteLine("Phuong trinh vo nghiem!");
                }
                else
                {
                    float xb1 = (float)-c / b;
                    Console.WriteLine("Phuong trinh co 1 nghiem x = " + xb1);
                }
            }
            else
            {
                float delta = (float)b * b - 4 * a * c;
                if (delta < 0)
                    Console.WriteLine("Phuong trinh vo nghiem!");
                else if (delta == 0)
                {
                    float xk = (float)-b / a;
                    Console.WriteLine("Phuong trinh co 1 nghiem kep x = " + xk);
                }
                else
                {
                    float x1 = (float)((-b) + Math.Sqrt(delta)) / (2 * a);
                    float x2 = (float)((-b) - Math.Sqrt(delta)) / (2 * a);
                    Console.WriteLine("Phuong trinh co 2 nghiem phan biet x1 = " + x1 + " x2 = " + x2);
                }    
            }

        }
    }
}
