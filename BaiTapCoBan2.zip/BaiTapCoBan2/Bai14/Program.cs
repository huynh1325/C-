﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap ngay: ");
            int d = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Nhap thang: ");
            int m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Nhap nam: ");
            int y = Convert.ToInt32(Console.ReadLine());
            if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0))
            {
                if (d == 29 && m == 2)
                {
                    Console.WriteLine("Ngay mai: 01/03/" + y);
                    Console.WriteLine("Hom qua: 28/02/" + y);
                }
                else if (d == 1 && m == 3)
                {
                    Console.WriteLine("Ngay mai: 02/03/" + y);
                    Console.WriteLine("Hom qua: 29/02/" + y);
                }
                else if ((m == 4 || m == 6 || m == 9 || m == 11) && d == 30)
                {
                    Console.WriteLine("Ngay mai: 01/" + (m + 1) + "/" + y);
                    Console.WriteLine("Hom qua: 29/" + m + "/" + y);
                }
                else if ((m == 5 || m == 7 || m == 10 || m == 12) && d == 1)
                {
                    Console.WriteLine("Ngay mai: 02/" + m + "/" + y);
                    Console.WriteLine("Hom qua: 30/" + (m - 1) + "/" + y);
                }
                else if (d == 31 && m == 12)
                {
                    Console.WriteLine("Ngay mai: 01/01/" + (y + 1));
                    Console.WriteLine("Hom qua: 30/12/" + y);
                }
                else if (d == 1 && m == 1)
                {
                    Console.WriteLine("Ngay mai: 02/01/" + y);
                    Console.WriteLine("Hom qua: 31/12/" + (y - 1));
                }
                else if (d == 31)
                {
                    Console.WriteLine("Ngay mai: 01/" + (m + 1) + "/" + y);
                    Console.WriteLine("Hom qua: 30/" + m + "/" + y);
                }
                else if (d == 1)
                {
                    Console.WriteLine("Ngay mai: 02/" + m + "/" + y);
                    Console.WriteLine("Hom qua: 31/" + (m - 1) + "/" + y);
                }
                else
                {
                    Console.WriteLine("Ngay mai: " + (d + 1) + "/" + m + "/" + y);
                    Console.WriteLine("Hom qua: " + (d - 1) + "/" + m + "/" + y);
                }
            }
            else
            {
                if (d == 28 && m == 2)
                {
                    Console.WriteLine("Ngay mai: 01/03/" + y);
                    Console.WriteLine("Hom qua: 27/02/" + y);
                }
                else if (d == 1 && m == 3)
                {
                    Console.WriteLine("Ngay mai: 02/03/" + y);
                    Console.WriteLine("Hom qua: 28/02/" + y);
                }
                else if ((m == 4 || m == 6 || m == 9 || m == 11) && d == 30)
                {
                    Console.WriteLine("Ngay mai: 01/" + (m + 1) + "/" + y);
                    Console.WriteLine("Hom qua: 29/" + m + "/" + y);
                }
                else if ((m == 5 || m == 7 || m == 10 || m == 12) && d == 1)
                {
                    Console.WriteLine("Ngay mai: 02/" + m + "/" + y);
                    Console.WriteLine("Hom qua: 30/" + (m - 1) + "/" + y);
                }
                else if (d == 31 && m == 12)
                {
                    Console.WriteLine("Ngay mai: 01/01/" + (y + 1));
                    Console.WriteLine("Hom qua: 30/12/" + y);
                }
                else if (d == 1 && m == 1)
                {
                    Console.WriteLine("Ngay mai: 02/01/" + y);
                    Console.WriteLine("Hom qua: 31/12/" + (y - 1));
                }
                else if (d == 31)
                {
                    Console.WriteLine("Ngay mai: 01/" + (m + 1) + "/" + y);
                    Console.WriteLine("Hom qua: 30/" + m + "/" + y);
                }
                else if (d == 1)
                {
                    Console.WriteLine("Ngay mai: 02/" + m + "/" + y);
                    Console.WriteLine("Hom qua: 31/" + (m - 1) + "/" + y);
                }
                else
                {
                    Console.WriteLine("Ngay mai: " + (d + 1) + "/" + m + "/" + y);
                    Console.WriteLine("Hom qua: " + (d - 1) + "/" + m + "/" + y);
                }    
            }    
        }
    }
}
