﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap phuong trinh: ");
            Console.Write("Nhap a: ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Nhap b: ");
            int b = Convert.ToInt32(Console.ReadLine());
            if (a == 0)
            {
                if (b == 0)
                    Console.WriteLine("Phuong trinh co vo so nghiem!");
                else
                    Console.WriteLine("Phuong trinh vo nghiem!");
            }
            else
            {
                float x = (float)-b / a;
                Console.WriteLine("Phuong trinh co 1 nghiem x = " + x);
            }    
        }
    }
}
