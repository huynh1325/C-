﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai22
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Huynh:
            Console.WriteLine("Nhap n: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int count = 2;
            int sum = 0;
            sum = sum + n + 1;
            if (n <= 0)
            {
                Console.WriteLine("Xin hay nhap so nguyen duong!!");
                goto Huynh;
            }
            else if (n == 1)
            {
                Console.WriteLine("Uoc so la: 1");
                Console.WriteLine("Co 1 uoc so, tong la: 1");
            }
            else
            {
                Console.Write("Cac uoc so la: 1 ");
                for (int i = 2; i <= (n / 2); i++)
                {
                    if (n % i == 0)
                    {
                        Console.Write( i + " " );
                        sum += i;
                        count++;
                    }
                }
                Console.Write(n);
                Console.WriteLine("\nCo " + count + " uoc so, tong la: " + sum);
            }    
        }
    }
}
