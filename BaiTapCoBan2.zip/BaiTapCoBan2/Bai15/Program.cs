﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap ngay: ");
            int d = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Nhap thang: ");
            int m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Nhap nam: ");
            int y = Convert.ToInt32(Console.ReadLine());
            int sum = (int)(30.42 * (m - 1) + d);
            if (m == 2 || ((y % 4 == 0 && y % 100 != 0) && m > 2 ) || ((y % 400 == 0) && m > 2))
            {
                sum = sum + 1;
            }
            if (m > 2 && m < 8)
            {
                sum = sum - 1;
            }
            Console.WriteLine("Ngay thu: " + sum);
        }
    }
}
