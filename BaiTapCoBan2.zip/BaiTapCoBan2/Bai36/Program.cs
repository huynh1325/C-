﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai36
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Huynh:
            Console.WriteLine("Nhap n: ");
            int n = Convert.ToInt32(Console.ReadLine());
            if (n < 1)
            {
                Console.WriteLine("Vui long nhap n la so nguyen duong!!");
                goto Huynh;
            }
            for (int i = 1; i <= n; i++)
            {
                Console.WriteLine()
            }    

        }
    }
}
