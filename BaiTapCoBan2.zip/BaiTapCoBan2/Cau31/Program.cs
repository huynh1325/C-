﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cau31
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bang cuu chuong");
            for (int i = 1;i<= 10;++i)
            {
                for (int j = 2; j <= 9;++j)
                    Console.Write(j + "x" + i + "=" + (i * j) + "\t");
                Console.WriteLine();
            }    
        }
    }
}
