﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap dien tich cua mat cau: ");
            const float pi = 3.141593f;
            float s = float.Parse(Console.ReadLine());
            float r = (float)Math.Sqrt(s / (4 * pi));
            float v = (float)((4 * pi * Math.Pow(r, 3))/3);
            Console.Write("The tich mat cau la: " + v);
            Console.ReadLine();
        }
    }
}
