﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai21
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap diem chuan : ");
            float dc = float.Parse(Console.ReadLine());
            Console.WriteLine("Nhap 3 mon thi: ");
            float m1 = float.Parse(Console.ReadLine());
            float m2 = float.Parse(Console.ReadLine());
            float m3 = float.Parse(Console.ReadLine());
            Console.WriteLine("Nhap khu vuc (A, B, C, X): ");
            string area = Console.ReadLine();
            Console.WriteLine("Nhap doi tuong (1, 2, 3, 0): ");
            int dt = Convert.ToInt32(Console.ReadLine());
            float diem = m1 + m2 + m3;
            switch ( area )
            {
                case "A" :
                    diem = diem + 2;
                    break;
                case "B":
                    diem = diem + 1;
                    break;
                case "C":
                    diem = (float)(diem + 0.5);
                    break;
            }
            switch (dt)
            {
                case 1:
                    diem = (float)(diem + 2.5);
                    break;
                case 2:
                    diem = (float)(diem + 1.5);
                    break;
                case 3:
                    diem = diem + 1;
                    break;
            }
            if (m1 == 0 || m2 == 0 || m3 == 0)
                Console.WriteLine("Rot [" + diem + "]");
            else if (dc > diem)
                Console.WriteLine("Rot [" + diem + "]");
            else
                Console.WriteLine("Dau [" + diem + "]");
        }
    }
}