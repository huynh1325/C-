﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap nam: ");
            int y = Convert.ToInt32(Console.ReadLine());
            Month:
            Console.WriteLine("Nhap thang: ");
            int m = Convert.ToInt32(Console.ReadLine());
            if (m > 12 || m < 1)
            {
                Console.WriteLine("Nhap sai!! Thang phai co gia tri tu 1 den 12.\nMoi ban nhap lai.");
                goto Month;
            }
            Day:
            Console.WriteLine("Nhap ngay: ");
            int d = Convert.ToInt32(Console.ReadLine());
            if (m == 2)
            {
                if ((y % 4 == 0 && y % 100 != 0)||(y % 400 == 0))
                {
                    if (d > 29 || d < 1)
                    {
                        Console.WriteLine("Nhap sai!! Moi ban nhap lai.");
                        goto Day;
                    }
                }
                else
                {
                    if (d > 28 || d < 1)
                    {
                        Console.WriteLine("Nhap sai!! Moi ban nhap lai.");
                        goto Day;
                    }
                }
            }
            else
            {
                if (m == 4 || m == 6 || m == 9 || m == 11)
                {
                    if (d > 30 || d < 1)
                    {
                        Console.WriteLine("Nhap sai!! Moi ban nhap lai.");
                        goto Day;
                    }
                }
                else
                {
                    if (d > 31 || d < 1 )
                    {
                        Console.WriteLine("Nhap sai!! Moi ban nhap lai.");
                        goto Day;
                    }

                }
            }
            int a = (14 - m) / 12;
            int year = y - a;
            int month = m + 12 * a - 2;
            int dayofweek = ((d + year + (year / 4) - (year / 100) + (year / 400) + (31 * month) / 12) % 7);
            switch (dayofweek)
            {
                case 0:
                    Console.WriteLine("Chua Nhat");
                    break;
                case 1:
                    Console.WriteLine("Thu 2");
                    break;
                case 2:
                    Console.WriteLine("Thu 3");
                    break;
                case 3:
                    Console.WriteLine("Thu 4");
                    break;
                case 4:
                    Console.WriteLine("Thu 5");
                    break;
                case 5:
                    Console.WriteLine("Thu 6");
                    break;
                case 6:
                    Console.WriteLine("Thu 7");
                    break;
            }
        }
    }
}
