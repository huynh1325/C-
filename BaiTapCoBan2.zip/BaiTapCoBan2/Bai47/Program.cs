﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai47
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Huynh:
            Console.WriteLine("Nhap n");
            int n = Convert.ToInt32(Console.ReadLine());
            int sum = 0;
            if (n < 1)
            {
                Console.WriteLine("Xin hay nhap n la so nguyen duong!!");
                goto Huynh;
            }
            if (n % 2 == 0)
                for (int i = 2; i <= n; i += 2)
                    sum += i;
            else
                for (int i = 1; i <= n; i += 2)
                    sum += i;
            Console.WriteLine("Sum = " + sum);
        }
    }
}
